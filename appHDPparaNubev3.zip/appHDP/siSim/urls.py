"""siSim URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
""" 
from django.contrib import admin

#from django.urls import include, path #django 2.0
from django.conf.urls import url,include
from django.conf.urls import handler404, handler500

urlpatterns = [
    ##forma 2.0
    #path('admin/', admin.site.urls),
    url(r'^admin/', admin.site.urls), #formaVieja
    #url(r'^', include('apps.simulacion.urls')),
    url(r'^', include(('apps.simulacion.urls'), namespace='simulacion')),
    #otra forma
    #url(r'^', include(('apps.simulacion.urls', 'apps.simulacion'), namespace='simulacion')),
]

handler404 = 'apps.simulacion.views.error_404_view'
handler500 = 'apps.simulacion.views.handler500'