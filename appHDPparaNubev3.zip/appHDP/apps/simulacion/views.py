#importacion de funciones de django
from django.shortcuts import render, redirect 	#redireccionar y renderizar
from django.http import HttpResponse			#funciones html
from django.contrib.auth.decorators import login_required, permission_required
from django.contrib.auth import authenticate, login, logout #para el Login
from django.urls import reverse, reverse_lazy #rediccionamiento inverso
from django.views.generic import CreateView, ListView
from django.contrib import auth #para autenticar la sesion
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.contrib.auth.models import User
from django.contrib.auth.views import logout
from django.shortcuts import render
from django.http import HttpResponse
#importanciones locales
from apps.simulacion.forms import MaterialForm, AdminForm
from apps.simulacion.models import Material, Administrador

#------------------------------AREA DE VISTAS----------------------------------------

#index (error)
def error_404_view(request, exception):
    return render(request,'paginas/404.html')

def handler500(request):
    return render(request, 'paginas/500.html', status=500)

#@login_required(login_url='simulacion:login')
def index_simulacion(request):
	return render(request, 'paginas/index.html') #direccion del index dentro de Plantillas

#vista que muestra la consulta de la lista de materiales
@login_required(login_url='simulacion:login')
def material_list(request):
	material = Material.objects.all()
	contexto = {'materiales':material}
	return render(request, 'paginas/material_list.html',contexto)

def administrador_list(request):
	administrador = Administrador.objects.all()
	contexto = {'administradores':administrador}
	return render(request, 'paginas/administrador_list.html',contexto)

#vista edicion material
#@login_required(login_url='simulacion:login')
def material_edit(request,id_material):
	material = Material.objects.get(id=id_material)
	if request.method == 'GET':
		form = MaterialForm(instance=material)
	else:
		form = MaterialForm(request.POST, instance=material)
		if form.is_valid():
			form.save()
			return redirect('simulacion:material_listar')
	return render(request, 'paginas/material_form.html', {'form':form})

@login_required(login_url='simulacion:login')	
def material_delete(request,id_material):
	material = Material.objects.get(id=id_material)
	if request.method == 'POST':
		material.delete()
		return redirect('simulacion:material_listar')
	return render(request, 'paginas/material_delete.html', {'material':material})


#@login_required(login_url='simulacion:login')
def simulador(request):
	material = Material.objects.all()
	contexto = {'materiales':material}
	return render(request, 'paginas/simulador.html',contexto)


#def login(request):
#	return render(request, 'paginas/login.html') #direccion del index dentro de Plantillas

@login_required(login_url='simulacion:login')
def material_view(request):
        if request.method=="POST":
            form=MaterialForm(request.POST)
            if form.is_valid():
                form.save()
            return redirect('simulacion:material_listar')
        else:
            form=MaterialForm()
        return render(request,'paginas/material_form.html',{"form":form})

def login(request):
    if request.method == 'POST':
        username = request.POST.get('username', None)
        password = request.POST.get('password', None)
        user = authenticate(username=username, password=password)
        if user:
            auth.login(request, user)
            return render(request, 'paginas/index.html')
        else:
            valor = "*Ingrese usuario valido o contraseña correcta"
            context = {'valor': valor}
            return render(request, 'paginas/login.html', context)
    context = {}
    return render(request, 'paginas/login.html')

#CLASES
class MaterialList(ListView):
	model = Material
	template_name = 'paginas/material_list.html'


class MaterialCreate(CreateView):
	model = Material
	form_class = MaterialForm
	template_name = 'paginas/material_form.html'
	success_url = reverse_lazy('simulacion:material_listar')