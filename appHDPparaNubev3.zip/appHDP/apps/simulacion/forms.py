from django import forms
from apps.simulacion.models import Material, Administrador

class MaterialForm(forms.ModelForm):

	class Meta:
		model = Material
		fields = {
		'nombreMat',
		'indice',
		'administrador',
		}
		labels = {
		'administrador': 'Administrador',
		'nombreMat': 'Nombre del material',
		'indice': 'Indice',
		}

		widgets = {
		'administrador': forms.Select(attrs={'class':'form-control'}),
		'nombreMat': forms.TextInput(attrs={'class':'form-control'}),
		'indice': forms.NumberInput(attrs={'class':'form-control'}),
		}

class AdminForm(forms.ModelForm):

	class Meta:
		model = Administrador
		fields = '__all__'