from django.db import models

# Create your models here.
class Administrador(models.Model):
	nombre = models.CharField(max_length=30,null=False)
	password = models.CharField(max_length=30,null=False)
	correo = models.EmailField()

	def __str__(self):
		return '{}'.format(self.nombre)

class Material(models.Model):
	nombreMat = models.CharField(max_length=30,null=False)
	indice = models.FloatField()
	administrador = models.ForeignKey(Administrador, null=False, blank=False, on_delete=models.CASCADE)

	def __str__(self):
		return '{}'.format(self.nombreMat)