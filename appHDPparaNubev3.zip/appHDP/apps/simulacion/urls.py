#importacion de funciones
#from django.urls import path
from django.conf.urls import url, include

#importaciones locales
from apps.simulacion.views import *

#nombre de aplicacion
app_name = 'simulacion'

urlpatterns = [
    url(r'^$',index_simulacion, name='index'),
    url(r'^simulador/$',simulador),
    #url(r'login/$',login),
    #url(r'^nuevo/$',MaterialCreate.as_view(), name='material_crear'),
    url(r'^nuevo/$',material_view, name='material_crear'),
	#url(r'^listar/$',MaterialList.as_view(), name='material_listar'),
    url(r'listar/$',material_list, name='material_listar'),
    url(r'admins/$',administrador_list, name='administrador_listar'),
    url(r'^editar/(?P<id_material>\d+)/$',material_edit, name='material_editar'),
    url(r'^eliminar/(?P<id_material>\d+)/$',material_delete, name='material_eliminar'),
    url(r'^login/$', login, name='login'),
    url(r'^salir$', logout, name="salir", kwargs={'next_page': '/'}),  
]