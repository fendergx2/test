from django.contrib import admin
from apps.simulacion.models import Administrador, Material
# Register your models here.
admin.site.register(Administrador)
admin.site.register(Material)